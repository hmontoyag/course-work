* THIS 4 tests (01 - 04) are for basic scenarios, the EVEN ones test cases where the sum of two friend's 		playtime yields an even average (X.0) the odd ones are for when the average is not an integer (X.5)
 
 
The two 'lone' tests test for when theres only one friend'ss plaaytime, for NS and S respectively. 

THE (10 - 11) following two tests test the situation of finding a playtime NS bounded by S's, and viceversa. This also checks situations where an S is next to an NS, towards
both directions, considering both tests <-S NS S ->;  <-NS S NS->

The following tests were used in the building process, and are not particularly designed to cover any one case (0 - 5)


**** Descriptions can be found above each test-group inside SwordFinder.java as well, in case the descriptions above aren't accurate as to which case they refer to. *****
